---
name: yijie-fixture-model-only
description: Synthetic contract fixture.
---

# Synthetic fixture

Return the supplied text unchanged.
