---
name: copywriting
description: Synthetic catalog contract fixture.
---

# Synthetic copywriting fixture

Return one short product sentence from supplied facts.
